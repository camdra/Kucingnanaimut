module.exports = {
  ownerNumber: ["6282221155218"], 
  botName: "Nanabot",
  autoRead: true,
  autoWelcome: true,
  antiLink: true,
  prefix: "."
}
